//
//  main.c
//  DHCPRelay
//
//  Created by Ludovic Vannoorenberghe on 1/05/14.
//  Copyright (c) 2014 Ludovic Vannoorenberghe. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[])
{

	// insert code here...
	printf("Hello, World!\n");
    return 0;
}

